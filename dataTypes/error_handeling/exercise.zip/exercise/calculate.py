from divide import divide

num1: int = int(input("Enter your first number : "))
num2: int = int(input("Enter your secound number : "))

print("Result:", divide(num1, num2))

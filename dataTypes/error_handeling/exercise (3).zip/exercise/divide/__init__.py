from .divide import divide

__all__ = ["divide"]

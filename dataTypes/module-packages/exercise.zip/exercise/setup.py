from setuptools import setup, find_packages

setup(
    name="mylibrary",
    version="1.0.0",
    packages=find_packages(),
    description="A simple library management system",
    author="Your Name",
    author_email="your_email@example.com",
    license="MIT",
    python_requires=">=3.7",
 )